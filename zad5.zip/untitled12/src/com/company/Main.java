package com.company;
import java.util.Scanner;
public class Main {
    public static void main(String[] args){
        Scanner console = new Scanner(System.in);

       // zad 1

        System.out.println("Wpisz x:");
        int x= console.nextInt();
        System.out.println("Wpisz y:");
        int y= console.nextInt();
        y=y+x-(x=y);
        System.out.println("Odp: ");
        System.out.println("x = "+x);
        System.out.println("y = "+y);

        // zad 2
        System.out.println("Wpisz liczbe: ");
        int a=console.nextInt();
        int b=a/100;
        int c=(a%100)/10;
        int d=a%10;
        int summOfNumbers=b+c+d;
        System.out.println("Odp: " +b+ " + " +c+ " + " +b+ " = " +summOfNumbers);

        // zad 3
        System.out.println("Wpisz a: ");
        int Aa=console.nextInt();
        int Ab=console.nextInt();
        System.out.println("Wpisz b");
        int Ba=console.nextInt();
        int Bb=console.nextInt();
        double q=Math.sqrt(((Ba-Aa)*(Ba-Aa))+((Bb-Ab)*(Bb-Ab)));
        System.out.println("Odp: " +d);
        Scanner keyboard = new Scanner(System.in);

        //zad 4
        System.out.println("Witamy w kontorze!");
        System.out.println("Wyberz kwote:");
        int price =30;
        String pln="1";
        String jpy="2";
        System.out.println("1 - PLN albo 2 - JPY?");
        String currency=keyboard.nextLine();
        while ((currency).equalsIgnoreCase(pln)){
            System.out.println("Wpisz kwote");
            int summ=keyboard.nextInt();
            int result=summ*price;
            System.out.println(summ+" PLN => "+result+" JPY");
            break;
        }
        while ((currency).equalsIgnoreCase(jpy)) {
            System.out.println("Wpisz kwote: ");
            int summ=keyboard.nextInt();
            int result=summ/price;
            System.out.println(summ+" JPY => "+result+" PLN");
            break;
        }
    }
}
